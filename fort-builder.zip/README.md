# Vorld

A WebGL Voxel Based - MineCraft esque - World Generator

Using [Fury](https://github.com/delphic/Fury) for rendering, based on the [Voxel Terrain](https://github.com/delphic/Fury/tree/master/demos/VoxelTerrain) demo.

## Generators
* Fort Generator

## Known Issues
At larger distances the mipmapping causes the blocks to bleed into one another resulting in noticable rendering artifacts.
